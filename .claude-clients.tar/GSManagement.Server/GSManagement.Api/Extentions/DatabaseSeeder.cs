using GSManagement.Domain.DB;
using GSManagement.Domain.Entities;
using GSManagement.Domain.Entities.Enums;
using Microsoft.EntityFrameworkCore;
using GSManagement.Api.Shared.Utils;

namespace GSManagement.Api.Extentions;

public static class DatabaseSeeder
{
    public static async Task SeedData(this WebApplication app)
    {
        using var scope = app.Services.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<GSDbContext>();

        if (context.Database.GetPendingMigrations().Any())
        {
            await context.Database.MigrateAsync();
        }

        // 1. Seed Permissions with Modules (seeds missing permissions dynamically)
        var existingPermissions = await context.Permissions
            .Select(p => p.PermissionName)
            .ToListAsync();

        var missingPermissions = Enum.GetValues<AppPermission>()
            .Except(existingPermissions)
            .Select(permission => new Permission
            {
                PermissionName = permission,
                Module = GetModuleFromPermission(permission),
                Description = GetDescription(permission),
                CreatedAt = DateTime.Now
            })
            .ToList();

        if (missingPermissions.Count > 0)
        {
            await context.Permissions.AddRangeAsync(missingPermissions);
            await context.SaveChangesAsync();

            // Grant newly created permissions to Admin role if Admin already exists
            var adminRole = await context.Roles
                .Include(r => r.Permissions)
                .FirstOrDefaultAsync(r => r.RoleName == Role.AdminRoleName);

            if (adminRole != null)
            {
                foreach (var permission in missingPermissions)
                {
                    adminRole.Permissions.Add(permission);
                }
                await context.SaveChangesAsync();
            }
        }

        // 2. Seed Roles
        if (!await context.Roles.AnyAsync())
        {
            var permissions = await context.Permissions.ToListAsync();

            // Fetch user module permissions dynamically
            var userModulePermissions = permissions
                .Where(p => p.Module == PermissionModule.User)
                .ToList();

            await context.Roles.AddRangeAsync(
                new Role { RoleName = Role.AdminRoleName, Permissions = permissions, CreatedAt = DateTime.Now }, // Admin gets all permissions
                new Role { RoleName = "HR", Permissions = userModulePermissions, CreatedAt = DateTime.Now },
                new Role { RoleName = "Operation", CreatedAt = DateTime.Now },
                new Role { RoleName = "Accountant", CreatedAt = DateTime.Now }
            );
            await context.SaveChangesAsync();
        }

        // 2b. HR runs the HR side of the app (staff, attendance, leave, shifts).
        // Granted idempotently so existing databases pick it up too. Other
        // roles get no permissions: they only use the self-service
        // /api/employee/* endpoints, which need just a login.
        var hr = await context.Roles
            .Include(r => r.Permissions)
            .FirstOrDefaultAsync(r => r.RoleName == "HR");

        if (hr != null)
        {
            PermissionModule[] hrModules =
                [PermissionModule.User, PermissionModule.Attendance, PermissionModule.Leave, PermissionModule.Shift];

            var hrMissing = await context.Permissions
                .Where(p => hrModules.Contains(p.Module))
                .ToListAsync();
            hrMissing = hrMissing.Where(p => hr.Permissions.All(x => x.Id != p.Id)).ToList();

            if (hrMissing.Count > 0)
            {
                foreach (var permission in hrMissing)
                    hr.Permissions.Add(permission);
                await context.SaveChangesAsync();
            }
        }

        // 2c. Clients: each operator handles their own clients (ClientOperators).
        // Operators see and update only the clients assigned to them; the
        // Operations Manager sees every client and assigns operators. Granted
        // idempotently so existing databases pick it up too.
        await GrantAsync(context, "Operation",
            AppPermission.ViewClient, AppPermission.CreateClient, AppPermission.UpdateClient);

        if (!await context.Roles.AnyAsync(r => r.RoleName == OperationsManagerRole))
        {
            context.Roles.Add(new Role
            {
                RoleName = OperationsManagerRole,
                Description = "Assigns clients to operators, sees every client, approves operations work",
                CreatedAt = DateTime.Now
            });
            await context.SaveChangesAsync();
        }
        await GrantAsync(context, OperationsManagerRole,
            AppPermission.ViewClient, AppPermission.CreateClient, AppPermission.UpdateClient,
            AppPermission.DeleteClient, AppPermission.ViewAllClients, AppPermission.AssignClient);

        // 3. Seed Users
        if (!await context.Users.AnyAsync())
        {
            var adminRole = await context.Roles.FirstAsync(r => r.RoleName == Role.AdminRoleName);
            var hrRole = await context.Roles.FirstAsync(r => r.RoleName == "HR");
            var operationRole = await context.Roles.FirstAsync(r => r.RoleName == "Operation");
            var accountantRole = await context.Roles.FirstAsync(r => r.RoleName == "Accountant");

            await context.Users.AddRangeAsync(
                new User
                {
                    UserName = "Ly Henglay",
                    Email = "henglay699@gmail.com",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("Henglay699@"),
                    Roles = new List<Role> { adminRole }
                },
                new User
                {
                    UserName = "Helen",
                    Email = "helen@gmail.com",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("helen@"),
                    Roles = new List<Role> { hrRole }
                },
                new User
                {
                    UserName = "Sary Chhunleang",
                    Email = "chhunleang@gmail.com",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("chhunleang@"),
                    Roles = new List<Role> { operationRole }
                },
                new User
                {
                    UserName = "Vichea Thnin",
                    Email = "vicheathnin@gmail.com",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("vicheathnin@"),
                    Roles = new List<Role> { operationRole }
                },
                new User
                {
                    UserName = "Ly Cheng",
                    Email = "lycheng@gmail.com",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("lycheng@"),
                    Roles = new List<Role> { accountantRole }
                }
            );
            await context.SaveChangesAsync();
        }

        // 4. Seed Attendance
        if (!await context.Attendances.AnyAsync())
        {
            var chhunleang = await context.Users.FirstAsync(u => u.Email == "chhunleang@gmail.com");
            var henglay = await context.Users.FirstAsync(u => u.Email == "henglay699@gmail.com");
            var thnin = await context.Users.FirstAsync(u => u.Email == "vicheathnin@gmail.com");
            var lycheng = await context.Users.FirstAsync(u => u.Email == "lycheng@gmail.com");
            var helen = await context.Users.FirstAsync(u => u.Email == "helen@gmail.com");

            await context.Attendances.AddRangeAsync(
                new Attendance
                {
                    UserId = chhunleang.Id,
                    Date = AppClock.Today,
                    CheckInTime = new TimeOnly(8, 0),
                    Status = AttendanceStatus.Present,
                    Remark = "Late"
                },
                new Attendance
                {
                    UserId = henglay.Id,
                    Date = AppClock.Today,
                    CheckInTime = new TimeOnly(8, 0),
                    CheckOutTime = new TimeOnly(16, 0),
                    Status = AttendanceStatus.Present,
                    Remark = "Arrived On Time"
                },
                new Attendance
                {
                    UserId = thnin.Id,
                    Date = AppClock.Today,
                    Status = AttendanceStatus.OnLeave,
                    Remark = "On Leave"
                },
                new Attendance
                {
                    UserId = lycheng.Id,
                    Date = AppClock.Today,
                    Status = AttendanceStatus.Absent,
                    Remark = "Absent Not Inform"
                },
                new Attendance
                {
                    UserId = helen.Id,
                    Date = AppClock.Today,
                    CheckInTime = new TimeOnly(8, 26),
                    CheckOutTime = new TimeOnly(16, 0),
                    Status = AttendanceStatus.Late,
                    Remark = "Late"
                }
            );
            await context.SaveChangesAsync();
        }

        // 5. Seed Default Shift (8:00 - 17:00 with 15 mins grace period)
        if (!await context.Shifts.AnyAsync())
        {
            await context.Shifts.AddAsync(new Shift
            {
                Name = "Regular Shift",
                StartTime = new TimeOnly(8, 0),
                EndTime = new TimeOnly(17, 0),
                GraceMinutes = 15,
                IsDefault = true
            });
            await context.SaveChangesAsync();
        }
    }

    public const string OperationsManagerRole = "Operations Manager";

    /// <summary>Adds the permissions to the role (if the role exists) without removing any.</summary>
    private static async Task GrantAsync(GSDbContext context, string roleName, params AppPermission[] wanted)
    {
        var role = await context.Roles
            .Include(r => r.Permissions)
            .FirstOrDefaultAsync(r => r.RoleName == roleName);
        if (role is null) return;

        var permissions = await context.Permissions
            .Where(p => wanted.Contains(p.PermissionName))
            .ToListAsync();
        var missing = permissions.Where(p => role.Permissions.All(x => x.Id != p.Id)).ToList();
        if (missing.Count == 0) return;

        foreach (var permission in missing)
            role.Permissions.Add(permission);
        await context.SaveChangesAsync();
    }

    private static PermissionModule GetModuleFromPermission(AppPermission permission)
    {
        return permission switch
        {
            AppPermission.ViewUser or AppPermission.CreateUser or AppPermission.UpdateUser or AppPermission.DeleteUser
                => PermissionModule.User,

            AppPermission.ViewRole or AppPermission.CreateRole or AppPermission.UpdateRole or AppPermission.DeleteRole
                => PermissionModule.Role,

            AppPermission.ViewPermission or AppPermission.CreatePermission or AppPermission.UpdatePermssion or AppPermission.DeletePermssion
                => PermissionModule.Permission,

            AppPermission.ViewAttendance or AppPermission.CreateAttendance or AppPermission.UpdateAttendance or AppPermission.DeleteAttendance
                => PermissionModule.Attendance,

            // Add this new block:
            AppPermission.ViewLeave or AppPermission.CreateLeave or AppPermission.UpdateLeave or AppPermission.DeleteLeave
                => PermissionModule.Leave,

            AppPermission.ViewClient or AppPermission.CreateClient or AppPermission.UpdateClient or AppPermission.DeleteClient
                or AppPermission.ViewAllClients or AppPermission.AssignClient
                => PermissionModule.Client,

            AppPermission.ViewShift or AppPermission.CreateShift or AppPermission.UpdateShift or AppPermission.DeleteShift
                => PermissionModule.Shift,

            _ => throw new ArgumentOutOfRangeException(nameof(permission), permission, "Unhandled permission enum value")
        };
    }
    private static string GetDescription(AppPermission permission) => permission switch
    {
        AppPermission.ViewUser
            => "Can " + nameof(AppPermission.ViewUser),
        AppPermission.CreateUser
            => "Can " + nameof(AppPermission.CreateUser),
        AppPermission.UpdateUser
            => "Can " + nameof(AppPermission.UpdateUser),
        AppPermission.DeleteUser
            => "Can " + nameof(AppPermission.DeleteUser),

        AppPermission.ViewRole
            => "Can " + nameof(AppPermission.ViewRole),
        AppPermission.CreateRole
            => "Can " + nameof(AppPermission.CreateRole),
        AppPermission.UpdateRole
            => "Can " + nameof(AppPermission.UpdateRole),
        AppPermission.DeleteRole
            => "Can " + nameof(AppPermission.DeleteRole),

        AppPermission.ViewPermission
            => "Can " + nameof(AppPermission.ViewPermission),
        AppPermission.CreatePermission
            => "Can " + nameof(AppPermission.CreatePermission),
        AppPermission.UpdatePermssion
            => "Can " + nameof(AppPermission.UpdatePermssion),
        AppPermission.DeletePermssion
            => "Can " + nameof(AppPermission.DeletePermssion),

        AppPermission.ViewAttendance
            => "Can " + nameof(AppPermission.ViewAttendance),
        AppPermission.CreateAttendance
            => "Can " + nameof(AppPermission.CreateAttendance),
        AppPermission.UpdateAttendance
            => "Can " + nameof(AppPermission.UpdateAttendance),
        AppPermission.DeleteAttendance
            => "Can " + nameof(AppPermission.DeleteAttendance),

        AppPermission.ViewLeave
        => "Can " + nameof(AppPermission.ViewLeave),
        AppPermission.CreateLeave
            => "Can " + nameof(AppPermission.CreateLeave),
        AppPermission.UpdateLeave
            => "Can " + nameof(AppPermission.UpdateLeave),
        AppPermission.DeleteLeave
            => "Can " + nameof(AppPermission.DeleteLeave),

        AppPermission.ViewClient
            => "Can " + nameof(AppPermission.ViewClient),
        AppPermission.CreateClient
            => "Can " + nameof(AppPermission.CreateClient),
        AppPermission.UpdateClient
            => "Can " + nameof(AppPermission.UpdateClient),
        AppPermission.DeleteClient
            => "Can " + nameof(AppPermission.DeleteClient),
        AppPermission.ViewAllClients
            => "Can see every client, not only assigned ones",
        AppPermission.AssignClient
            => "Can assign operators to clients",

        AppPermission.ViewShift
            => "Can " + nameof(AppPermission.ViewShift),
        AppPermission.CreateShift
            => "Can " + nameof(AppPermission.CreateShift),
        AppPermission.UpdateShift
            => "Can " + nameof(AppPermission.UpdateShift),
        AppPermission.DeleteShift
            => "Can " + nameof(AppPermission.DeleteShift),

        _ => throw new ArgumentOutOfRangeException(nameof(permission), permission, "Unhandled permission enum value")
    };
}