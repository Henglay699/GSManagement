namespace GSManagement.Domain.Entities.Enums;

public enum AppPermission
{
    //User
    ViewUser, CreateUser, UpdateUser, DeleteUser,

    //Role
    ViewRole, CreateRole, UpdateRole, DeleteRole,

    // Permission
    ViewPermission, CreatePermission, UpdatePermssion, DeletePermssion,

    // Attendance
    ViewAttendance, CreateAttendance, UpdateAttendance, DeleteAttendance,

    //Leave
    ViewLeave, CreateLeave, UpdateLeave, DeleteLeave,

    //Client
    ViewClient, CreateClient, UpdateClient, DeleteClient,

    // Shift
    ViewShift, CreateShift, UpdateShift, DeleteShift,
}

