﻿using GSManagement.Domain.Entities;
using GSManagement.Domain.Entities.JointEntities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GSManagement.Domain.EntityConfig;

internal class UserConfig : IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> builder)
    {
        builder.HasKey(u => u.Id);
        builder.HasIndex(e => e.Email).IsUnique();

        builder.Property(e => e.Id).ValueGeneratedOnAdd();
        builder.Property(u => u.UserName)
               .IsRequired()
               .HasMaxLength(200);
        builder.Property(u => u.Email)
               .HasMaxLength(60);

        // user-role
       // UserConfig.cs
builder.HasMany(u => u.Roles)
       .WithMany(r => r.Users)
       .UsingEntity<UserRole>(
           j => j.ToTable("UserRoles")
       );

        // Deleting a shift moves its employees back to the default shift.
        builder.HasOne(u => u.Shift)
               .WithMany()
               .HasForeignKey(u => u.ShiftId)
               .OnDelete(DeleteBehavior.SetNull);

        // user-refreshtoken
        builder.HasMany(u => u.RefreshTokens)
               .WithOne(rt => rt.User)
               .HasForeignKey(rt => rt.UserId)
               .OnDelete(DeleteBehavior.Cascade);
    }
}