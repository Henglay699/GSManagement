import { useCallback, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAsync } from "../../hooks/useAsync";
import { getErrorMessage } from "../../lib/api";
import { paths } from "../../lib/paths";
import { fetchRoles } from "../../services/roleService";
import type { PhotoChange, UserFormData } from "../../types/user";
import {
  ArrowLeft,
  Loader2,
  ShieldCheck,
  User as UserIcon,
} from "lucide-react";
import PhotoPicker from "./PhotoPicker";

interface UserFormProps {
  initialValues?: UserFormData;
  initialImageUrl?: string | null;
  onSubmit: (data: UserFormData, photo: PhotoChange) => Promise<void>;
  isEditMode?: boolean;
}

function UserForm({
  initialValues,
  initialImageUrl,
  onSubmit,
  isEditMode = false,
}: UserFormProps) {
  const navigate = useNavigate();
  // Edit pages only render this form once the user has loaded, so the
  // initial values can seed state directly.
  const [userName, setUserName] = useState(initialValues?.userName ?? "");
  const [email, setEmail] = useState(initialValues?.email ?? "");
  const [isActive, setIsActive] = useState(initialValues?.isActive ?? true);
  const [password, setPassword] = useState("");
  const [selectedRoleIds, setSelectedRoleIds] = useState<number[]>(
    initialValues?.roleIds ?? [],
  );

  const [photo, setPhoto] = useState<PhotoChange>(undefined);

  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const roles = useAsync(
    useCallback(() => fetchRoles(1, 100, ""), []),
    "Failed to load roles.",
  );
  const availableRoles = roles.data?.items ?? [];
  const loadingRoles = roles.loading;

  const handleRoleToggle = (roleId: number) => {
    setSelectedRoleIds((prev) =>
      prev.includes(roleId)
        ? prev.filter((id) => id !== roleId)
        : [...prev, roleId],
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setErrorMessage(null);
    try {
      await onSubmit(
        {
          userName,
          email,
          isActive,
          roleIds: selectedRoleIds,
          ...(password.trim() ? { password } : {}),
        },
        photo,
      );
      navigate(paths.users);
    } catch (error) {
      setErrorMessage(getErrorMessage(error, "Failed to save user."));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="w-full space-y-6">
      <form onSubmit={handleSubmit}>
        {/* Full Screen Main Container */}
        <div className="bg-surface p-6 rounded-2xl shadow-sm border border-slate-200 dark:border-line space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-line">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => navigate(-1)}
                className="p-2 rounded-xl text-fg-2 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors"
              >
                <ArrowLeft size={20} />
              </button>
              <div>
                <h1 className="text-xl font-bold text-slate-800 dark:text-white">
                  {isEditMode ? "Update User" : "Create New User"}
                </h1>
                <p className="text-xs text-fg-2">
                  {isEditMode
                    ? "Modify existing user account details and role permissions"
                    : "Fill in the details below to onboard a new user"}
                </p>
              </div>
            </div>

            {/* Action Buttons Header */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => navigate(-1)}
                className="px-4 py-2 text-sm font-medium text-fg-2 bg-slate-100 dark:bg-subtle hover:bg-slate-200 dark:hover:bg-zinc-700 rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="inline-flex items-center gap-2 px-5 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors shadow-md shadow-indigo-100 dark:shadow-none disabled:opacity-50"
              >
                {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
                <span>{isEditMode ? "Save Changes" : "Create User"}</span>
              </button>
            </div>
          </div>

          {errorMessage && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/50 text-rose-600 dark:text-rose-400 rounded-xl text-sm">
              {errorMessage}
            </div>
          )}

          {/* Grid Layout: Assign Roles on Left, Account Info on Right */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* LEFT COLUMN: Assign Roles */}
            <div className="bg-slate-50/70 dark:bg-subtle p-5 rounded-xl border border-slate-200/80 dark:border-line space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-200 dark:border-line-strong">
                <ShieldCheck
                  size={18}
                  className="text-indigo-600 dark:text-indigo-400"
                />
                <h2 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-wide">
                  Assign Roles
                </h2>
              </div>

              {loadingRoles ? (
                <div className="flex items-center gap-2 text-xs text-fg-3 dark:text-white0 py-4">
                  <Loader2 className="w-4 h-4 animate-spin text-indigo-600 dark:text-indigo-400" />
                  Loading roles...
                </div>
              ) : availableRoles.length === 0 ? (
                <p className="text-xs text-fg-3 dark:text-white0 italic py-2">
                  No roles available
                </p>
              ) : (
                <div className="flex flex-col gap-2 pt-1">
                  {availableRoles.map((role) => {
                    const isChecked = selectedRoleIds.includes(role.id);
                    return (
                      <button
                        key={role.id}
                        type="button"
                        onClick={() => handleRoleToggle(role.id)}
                        className={`flex items-center justify-between w-full px-4 py-3 rounded-xl text-xs font-medium border text-left transition-all ${
                          isChecked
                            ? "bg-indigo-600 text-white border-indigo-600 shadow-sm"
                            : "bg-surface text-fg-2 border-slate-200 dark:border-line-strong hover:bg-slate-100 dark:hover:bg-zinc-800"
                        }`}
                      >
                        <span>{role.roleName}</span>
                        <span className="font-bold">
                          {isChecked ? "✓" : "+"}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* RIGHT COLUMN: User Account Details */}
            <div className="lg:col-span-2 space-y-5">
              <div className="flex items-center gap-2 pb-2 border-b border-line">
                <UserIcon
                  size={18}
                  className="text-indigo-600 dark:text-indigo-400"
                />
                <h2 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-wide">
                  Account Details
                </h2>
              </div>

              <PhotoPicker
                initialImageUrl={initialImageUrl}
                photo={photo}
                onChange={setPhoto}
                onError={setErrorMessage}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-fg-2 uppercase mb-1">
                    Username
                  </label>
                  <input
                    type="text"
                    required
                    className="w-full px-4 py-2.5 bg-white dark:bg-subtle border border-slate-200 dark:border-line-strong rounded-xl text-sm text-fg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all placeholder:text-fg-3 dark:placeholder:text-white0"
                    placeholder="e.g. john_doe"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-fg-2 uppercase mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    className="w-full px-4 py-2.5 bg-white dark:bg-subtle border border-slate-200 dark:border-line-strong rounded-xl text-sm text-fg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all placeholder:text-fg-3 dark:placeholder:text-white0"
                    placeholder="e.g. john@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-fg-2 uppercase mb-1">
                  {isEditMode ? "New Password (Optional)" : "Password"}
                </label>
                <input
                  type="password"
                  required={!isEditMode}
                  className="w-full px-4 py-2.5 bg-white dark:bg-subtle border border-slate-200 dark:border-line-strong rounded-xl text-sm text-fg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all placeholder:text-fg-3 dark:placeholder:text-white0"
                  placeholder={
                    isEditMode
                      ? "Leave blank to keep current password"
                      : "Enter password"
                  }
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>

              <div className="flex items-center gap-3 pt-2">
                <input
                  type="checkbox"
                  id="isActiveToggle"
                  checked={isActive}
                  onChange={(e) => setIsActive(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded border-slate-300 dark:border-zinc-600 dark:bg-subtle focus:ring-indigo-500 cursor-pointer"
                />
                <label
                  htmlFor="isActiveToggle"
                  className="text-sm font-medium text-fg-2 cursor-pointer"
                >
                  Account Active
                </label>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}

export default UserForm;
